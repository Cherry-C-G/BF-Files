﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SqlConnectionExamples
{
    public class StudentClass
    {
        public int ClassId { get; set; }
        public string ClassName { get; set; }
    }
}
