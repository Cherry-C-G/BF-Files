﻿using Microsoft.Build.Framework;

namespace FormExample.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
