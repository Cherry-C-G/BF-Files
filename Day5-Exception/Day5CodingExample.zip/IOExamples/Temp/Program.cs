﻿using System;
using System.IO;
using System.Reflection.PortableExecutable;

namespace Temp
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
