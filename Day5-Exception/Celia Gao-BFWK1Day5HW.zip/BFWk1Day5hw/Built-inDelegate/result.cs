﻿//namespace Built_inDelegate
//{
//    public class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Hello, World!");
//        }

namespace Built_inDelegate
{
    internal class result
    {
    }
}