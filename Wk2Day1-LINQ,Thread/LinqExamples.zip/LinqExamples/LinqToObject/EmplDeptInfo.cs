﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinqToObject
{
    internal class EmplDeptInfo
    {
        public int EmplId { get; set; }
        public string EmplName { get; set; }
        public string DeptName { get; set; }
    }

}
