﻿namespace CarLINQ
{
    internal class Car
    {
        public string Color { get; set; }
        public int Price { get; set; }
    }
}