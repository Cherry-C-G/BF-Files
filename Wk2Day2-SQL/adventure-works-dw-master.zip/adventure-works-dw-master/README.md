# adventure-works-dw
The Adventure Works Datawarehouse ported to SQL Server

Order of script files:
./creates/create-database-tables.sql
./inserts/*
./creates/add-constraints.sql