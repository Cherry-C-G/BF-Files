﻿namespace BF_HW2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double myDouble = 11.11;
            int myInt = (int)myDouble;
            //Console.WriteLine("Hello, World!");
        }
    }
}