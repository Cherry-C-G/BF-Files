﻿using System;

namespace NullableExamples
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
