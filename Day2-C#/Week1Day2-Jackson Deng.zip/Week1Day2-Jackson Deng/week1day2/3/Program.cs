﻿namespace _3;
class Program
{

    static void Main(string[] args)
    {
        Console.WriteLine($"og  sq  cube");
        for (int i = 1; i <= 10; i++)
        {
            Console.WriteLine($"{i}   {i*i}   {i*i*i}");
        }


        Console.WriteLine("Hello, World!");
    }
}

