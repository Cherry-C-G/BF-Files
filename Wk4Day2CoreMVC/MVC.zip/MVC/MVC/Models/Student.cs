﻿namespace MVC.Models
{
    public class Student
    {
        public string? lastname { get; set; }
        public string? firstname{ get; set; }
        public int? age { get; set; }
    }
}
